package com.hihonor.hwddmp.health.lefu.sdk;

import com.peng.ppscale.vo.PPBodyFatModel;

public class HistoryCallback {

    public void onCategoryADataComing(PPBodyFatModel categoryAData) {

    }

    public void onCategoryBDataComing(PPBodyFatModel categoryBData) {

    }

    public void onFailed(int errCode, String errMsg) {

    }

}
