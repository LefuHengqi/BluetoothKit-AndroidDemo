package com.hihonor.hwddmp.health.lefu.sdk;

import com.peng.ppscale.vo.PPBodyFatModel;

public class CategoryLefuScaleDataCallback {

    public void onResult(PPBodyFatModel categoryAData, boolean isLock) {

    }

    public void onFailed(int errCode, String errMsg) {

    }


}
