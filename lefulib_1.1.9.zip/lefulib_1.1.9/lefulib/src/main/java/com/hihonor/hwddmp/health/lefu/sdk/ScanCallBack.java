package com.hihonor.hwddmp.health.lefu.sdk;

import com.peng.ppscale.vo.PPDeviceModel;

public class ScanCallBack {

    public void getScanResult(PPDeviceModel deviceModel){

    }

}
