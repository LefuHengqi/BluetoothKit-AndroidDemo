package com.lefu.ppscale.ble;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.hihonor.hwddmp.health.LefuScaleMeasureKit;
import com.hihonor.hwddmp.health.callback.ConnectCallback;
import com.hihonor.hwddmp.health.callback.DataCallback;
import com.hihonor.hwddmp.health.callback.DeviceStateListener;
import com.hihonor.hwddmp.health.callback.HealthDiscoveryCallback;
import com.hihonor.hwddmp.health.callback.InfoManageCallback;
import com.hihonor.hwddmp.health.callback.InitCallback;
import com.hihonor.hwddmp.health.data.DeviceParameter;
import com.hihonor.hwddmp.health.data.HealthData;
import com.hihonor.hwddmp.health.data.HealthDeviceInfo;
import com.hihonor.hwddmp.health.data.HealthDiscoverInfo;
import com.hihonor.hwddmp.health.data.UserInfo;
import com.hihonor.hwddmp.health.lefu.CategoryLefuScaleDeviceController;
import com.hihonor.hwddmp.health.lefu.LefuScaleSDK;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleConnectCallback;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleDataCallback;
import com.hihonor.hwddmp.health.lefu.sdk.InitListener;
import com.hihonor.hwddmp.health.lefu.sdk.InitStatus;
import com.hihonor.hwddmp.health.lefu.sdk.ScanCallBack;
import com.hihonor.hwddmp.health.lefu.sdk.UserCallback;
import com.hihonor.hwddmp.health.measuredata.HealthDataContent;
import com.lefu.healthu.business.mine.binddevice.BindDeviceWiFiLockSelectConfigNetDialog;
import com.lefu.ppscale.ble.model.DataUtil;
import com.lefu.ppscale.db.dao.DBManager;
import com.lefu.ppscale.db.dao.DeviceModel;
import com.peng.ppscale.business.ble.PPScale;
import com.peng.ppscale.business.device.PPUnitType;
import com.peng.ppscale.vo.PPBodyFatModel;
import com.peng.ppscale.vo.PPDeviceModel;
import com.peng.ppscale.vo.PPUserModel;

import java.util.List;
import java.util.Locale;

public class HonorScaleActivity extends AppCompatActivity {

    TextView weightTextView;
    TextView device_info;
    TextView device_state;

    public static final String SEARCH_TYPE = "SearchType";
    private String devModel;

    // 厂商鉴权所用密钥
    private String deviceMac;
    private CategoryLefuScaleDeviceController deviceController;
    private HealthDeviceInfo healthDeviceInfo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_honor_device);
        weightTextView = findViewById(R.id.weightTextView);
        device_info = findViewById(R.id.device_info);
        device_state = findViewById(R.id.device_state);

        devModel = "LFAston-B19";

        LefuScaleMeasureKit scaleMeasureKit = new LefuScaleMeasureKit();

        deviceController = new CategoryLefuScaleDeviceController(HonorScaleActivity.this, devModel);

        scaleMeasureKit.init(HonorScaleActivity.this, new InitCallback() {
            @Override
            public void onSuccess() {
                Log.i("TAG", "init success");
                startScanData();
            }

            @Override
            public void onFailed(String errMsg) {

            }
        });

    }

    private void startScanData() {
        device_state.setText("开始扫描");
        deviceController.startDiscovery(devModel, new HealthDiscoveryCallback() {

            @Override
            public void onDeviceFound(HealthDiscoverInfo discoverInfo) {

                DeviceModel device = DBManager.manager().getDevice(discoverInfo.getAddress());
                if (device != null) {
                    deviceMac = discoverInfo.getAddress();

                    device_state.setText("扫描到设备");
                    device_info.setText(discoverInfo.getAddress());

                    healthDeviceInfo = new HealthDeviceInfo();
                    healthDeviceInfo.setAddress(deviceMac);
                    healthDeviceInfo.setDeviceName(discoverInfo.getDeviceName());

                    UserInfo userInfo = new UserInfo();
                    userInfo.setBirth("1991-02-10");
                    userInfo.setHeight(180);
                    userInfo.setSex(true);

                    deviceController.manageUser(HealthDataContent.CMD_SET_USERINFO, healthDeviceInfo, userInfo, manageCallback);

                    deviceController.registerDeviceStateListener(deviceStateListener);

                    deviceController.connect(healthDeviceInfo, connectCallback);

                }
            }

            @Override
            public void onDiscoverResult(int code, String codeReason) {

            }

        });
    }

    DeviceStateListener deviceStateListener = new DeviceStateListener() {

        @Override
        public void onStateChange(int state, String errMsg) {

        }
    };

    InfoManageCallback manageCallback = new InfoManageCallback() {
        @Override
        public void onParaInfoSuccess(String nodeId, DeviceParameter deviceParameter) {

        }

        @Override
        public void onUserInfoSuccess(String nodeId, List<UserInfo> userInfoList) {

        }

        @Override
        public void onFailed(String nodeId, int errorCode, String errMsg) {

        }
    };


    ConnectCallback connectCallback = new ConnectCallback() {

        public void onSuccess() {
            deviceController.stopDiscovery();
            device_state.setText("连接成功");
            deviceController.startMeasure(healthDeviceInfo, new DataCallback() {
                @Override
                public void onDataChanged(String nodeId, HealthData healthData) {
                    weightTextView.setText(String.format(Locale.US, "锁定数据：%fkg", healthData.getDouble(HealthDataContent.KEY_WEIGHT_KG, 0.0)));
                }

                @Override
                public void onProgressChanged(String nodeId, HealthData healthData) {
                    weightTextView.setText(String.format(Locale.US, "过程数据：%fkg", healthData.getDouble(HealthDataContent.KEY_WEIGHT_KG, 0.0)));
                }

                @Override
                public void onFailed(String nodeId, int errCode, String errMsg) {
                    weightTextView.setText(String.format(Locale.US, "测量失败：errCode :%d errMsg: %s", errCode, errMsg));
                }

            });
        }

        public void onFailed(int errCode, String errMsg) {

        }
    };


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (deviceController != null) {
            deviceController.stopMeasure(healthDeviceInfo, new DataCallback() {
                @Override
                public void onDataChanged(String nodeId, HealthData healthData) {

                }

                @Override
                public void onProgressChanged(String nodeId, HealthData healthData) {

                }

                @Override
                public void onFailed(String nodeId, int errCode, String errMsg) {

                }
            });
            deviceController.stopDiscovery();
            deviceController.disConnect(healthDeviceInfo, new ConnectCallback() {

                @Override
                public void onSuccess() {
                    deviceController.unregisterDeviceStateListener();
                }

                @Override
                public void onFailed(int errCode, String errMsg) {

                }
            });
        }
    }
}
