package com.hihonor.hwddmp.health.lefu.sdk;

import android.util.Log;

import com.hihonor.hwddmp.health.data.HealthData;
import com.hihonor.hwddmp.health.measuredata.BodyFatData;
import com.hihonor.hwddmp.health.measuredata.HealthDataContent;
import com.peng.ppscale.business.device.PPUnitType;
import com.peng.ppscale.util.PPUtil;
import com.peng.ppscale.vo.PPBodyFatModel;
import com.peng.ppscale.vo.PPScaleDefine;

import java.util.ArrayList;
import java.util.List;

public class DataHelper {
    public static HealthData convertHealthData(PPBodyFatModel bodyFatModel) {

        String TAG = "convertHealthData";

        HealthData healthData = new HealthData();
//        BodyFatData bodyFatData = new BodyFatData();
        List<String> keyList = new ArrayList<>();
        List<String> dataTypeList = new ArrayList<>();
        List<String> valueList = new ArrayList<>();

        keyList.add(HealthDataContent.KEY_WEIGHT);//体重单位由 weightUnit 决定
        keyList.add(HealthDataContent.KEY_WEIGHT_KG);//体重（kg）
        keyList.add(HealthDataContent.KEY_BMI);//BMI
        keyList.add(HealthDataContent.KEY_FAT_KG);//脂肪重量（kg）
        keyList.add(HealthDataContent.KEY_BODY_FAT_RATE);//体脂率（%）
        keyList.add(HealthDataContent.KEY_SUB_FAT_RATE);//皮下脂肪率（%）
        keyList.add(HealthDataContent.KEY_LEAN_BODY_WEIGHT_KG);//去脂体重（kg）
        keyList.add(HealthDataContent.KEY_VISCERAL_FAT_INDEX);//内脏脂肪指数
        keyList.add(HealthDataContent.KEY_WATER_CONTENT_KG);//含水量（kg）
        keyList.add(HealthDataContent.KEY_BODY_WATER_RATE);//骨骼肌率（%）
        keyList.add(HealthDataContent.KEY_SKELETAL_MUSCLE_RATE);//骨骼肌率（%）
        keyList.add(HealthDataContent.KEY_BONE_KG);//骨量（kg）
        keyList.add(HealthDataContent.KEY_BONE_SALT_KG);//骨盐量（kg）
        keyList.add(HealthDataContent.KEY_BASAL_METABOLISM);//基础代谢(kcal)
        keyList.add(HealthDataContent.KEY_ACTIVE_METABOLISM);//活动代谢(kcal)
        keyList.add(HealthDataContent.KEY_PROTEIN_KG);//蛋白质量（kg）
        keyList.add(HealthDataContent.KEY_PROTEIN_RATE);//蛋白质（%）
        keyList.add(HealthDataContent.KEY_MUSCLE_KG);//肌肉量（kg）
        keyList.add(HealthDataContent.KEY_MUSCLE_RATE);//肌肉率（%）
        keyList.add(HealthDataContent.KEY_PHYSICAL_AGE);//身体年龄（岁）
        keyList.add(HealthDataContent.KEY_SCORE);//分数
        keyList.add(HealthDataContent.KEY_HEART_RATE);//心率
        keyList.add(HealthDataContent.KEY_HEART_INDEX);//心脏指数
        keyList.add(HealthDataContent.KEY_OBESITY_DEGREE);//肥胖度

        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_INTEGER);
        dataTypeList.add(HealthDataContent.DATA_TYPE_DOUBLE);

        String weightKg = String.valueOf(PPUtil.getWeightValue(PPUnitType.Unit_KG, bodyFatModel.getPpWeightKg(), PPScaleDefine.PPDeviceAccuracyType.PPDeviceAccuracyTypePoint005.getType()));

        valueList.add(weightKg);
        valueList.add(weightKg);
        valueList.add(String.valueOf(bodyFatModel.getPpBMI()));
        valueList.add(String.valueOf(bodyFatModel.getPpBodyfatKg()));
        valueList.add(String.valueOf(bodyFatModel.getPpBodyfatPercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpVFPercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpLoseFatWeightKg()));
        valueList.add(String.valueOf(bodyFatModel.getPpVFAL()));
        valueList.add(String.valueOf(bodyFatModel.getPpWaterPercentage() * bodyFatModel.getPpWeightKg()));
        valueList.add(String.valueOf(bodyFatModel.getPpWaterPercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpBonePercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpBoneKg()));
        valueList.add(String.valueOf(0.0));//骨盐量
        valueList.add(String.valueOf(bodyFatModel.getPpBMR()));
        valueList.add(String.valueOf(0.0));//活动代谢(kcal)
        valueList.add(String.valueOf(bodyFatModel.getPpProteinPercentage() * bodyFatModel.getPpWeightKg()));
        valueList.add(String.valueOf(bodyFatModel.getPpProteinPercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpMuscleKg()));
        valueList.add(String.valueOf(bodyFatModel.getPpMusclePercentage()));
        valueList.add(String.valueOf(bodyFatModel.getPpBodyAge()));
        valueList.add(String.valueOf(bodyFatModel.getPpBodyScore()));
        valueList.add(String.valueOf(bodyFatModel.getPpHeartRate()));
        valueList.add(String.valueOf(0));//心脏指数
        valueList.add(String.valueOf(0));//肥胖度

        healthData.setKeyList(keyList);
        healthData.setDataTypeList(dataTypeList);
        healthData.setValueList(valueList);

        Log.d(TAG, "weightKg: " + weightKg);

        return healthData;
    }

}
