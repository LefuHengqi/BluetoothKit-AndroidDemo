package com.hihonor.hwddmp.health.lefu.sdk;

public class CategoryLefuScaleConnectCallback {
    public void onSuccess() {

    }

    public void onFailed(int errCode, String errMsg) {

    }

}
