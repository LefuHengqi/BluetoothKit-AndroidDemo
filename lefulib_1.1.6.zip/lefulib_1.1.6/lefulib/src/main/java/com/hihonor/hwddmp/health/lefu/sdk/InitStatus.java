package com.hihonor.hwddmp.health.lefu.sdk;

public class InitStatus {
}
