package com.hihonor.hwddmp.health.lefu.sdk;

public class InitListener {

    public void onInitSuccess(InitStatus initStatus) {

    }

    public void onInitFailed(String msg) {

    }

}
