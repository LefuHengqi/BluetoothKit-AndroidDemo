package com.hihonor.hwddmp.health.lefu;

import android.content.Context;
import android.util.Log;

import com.hihonor.hwddmp.health.api.HealthDeviceController;
import com.hihonor.hwddmp.health.callback.ClearCallback;
import com.hihonor.hwddmp.health.callback.ConnectCallback;
import com.hihonor.hwddmp.health.callback.DataCallback;
import com.hihonor.hwddmp.health.callback.DeviceCapacityCallback;
import com.hihonor.hwddmp.health.callback.DeviceStateListener;
import com.hihonor.hwddmp.health.callback.EquipmentInfoCallback;
import com.hihonor.hwddmp.health.callback.ExtendCmdCallback;
import com.hihonor.hwddmp.health.callback.HealthDiscoveryCallback;
import com.hihonor.hwddmp.health.callback.HistoryDataCallback;
import com.hihonor.hwddmp.health.callback.InfoManageCallback;
import com.hihonor.hwddmp.health.data.CallbackStatus;
import com.hihonor.hwddmp.health.data.DeviceCapacity;
import com.hihonor.hwddmp.health.data.DeviceParameter;
import com.hihonor.hwddmp.health.data.EquipmentInfo;
import com.hihonor.hwddmp.health.data.HealthData;
import com.hihonor.hwddmp.health.data.HealthDeviceInfo;
import com.hihonor.hwddmp.health.data.HealthDiscoverInfo;
import com.hihonor.hwddmp.health.data.UserInfo;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleConnectCallback;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleDataCallback;
import com.hihonor.hwddmp.health.lefu.sdk.DataHelper;
import com.hihonor.hwddmp.health.lefu.sdk.HistoryCallback;
import com.hihonor.hwddmp.health.lefu.sdk.ScanCallBack;
import com.hihonor.hwddmp.health.lefu.sdk.UserCallback;
import com.hihonor.hwddmp.health.measuredata.HealthDataContent;
import com.peng.ppscale.vo.PPBodyFatModel;
import com.peng.ppscale.vo.PPDeviceModel;

import java.util.ArrayList;
import java.util.List;

// 品类A的 HealthDeviceController,CategoryA代指品类A名
public class CategoryLefuScaleDeviceController extends HealthDeviceController {
    private final String TAG = "CategoryADeviceController";

    private Context context;
    private DeviceStateListener deviceStateListener;
    private String devModel;
    private LefuScaleSDK instance;

    public CategoryLefuScaleDeviceController(Context context, String devModel) {
        this.context = context;
        this.devModel = devModel;
        this.instance = LefuScaleSDK.getInstance();
    }

    @Override
    public int startDiscovery(String devModel, HealthDiscoveryCallback callback) {
        Log.i(TAG, "startDiscovery, devModel: " + devModel);
        if (devModel == null || callback == null) {
            Log.e(TAG, "startDiscovery: callback is null");
            return HealthDataContent.DISCOVER_ERROR;
        }
        // 需要将三方回调转为health的回调
        ScanCallBack scanCallBack = new ScanCallBack() {

            public void getScanResult(PPDeviceModel bluetoothDevice) {
                HealthDiscoverInfo healthDiscoverInfo = new HealthDiscoverInfo();
                healthDiscoverInfo.setAddress(bluetoothDevice.getDeviceMac());
                healthDiscoverInfo.setDeviceName(bluetoothDevice.getDeviceName());
                // setDevIdHash时传入mac地址即可（大写，带”:“）
                healthDiscoverInfo.setDevIdHash(bluetoothDevice.getDeviceMac());
                callback.onDeviceFound(healthDiscoverInfo);
            }
        };
        instance.scanDevice(context, devModel, scanCallBack);
        return HealthDataContent.DISCOVER_SUCCESS;
    }

    @Override
    public int stopDiscovery() {
        Log.i(TAG, "stopDiscovery");
        instance.stopScan();
        return HealthDataContent.DISCOVER_SUCCESS;
    }

    @Override
    public int registerDeviceStateListener(DeviceStateListener listener) {
        Log.i(TAG, "registerDeviceStateListener");
        if (listener == null) {
            return HealthDataContent.ERROR;
        }
        this.deviceStateListener = listener;
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int unregisterDeviceStateListener() {
        Log.i(TAG, "unregisterDeviceStateListener");
        this.deviceStateListener = null;
        this.instance = null;
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int getEquipmentInfo(EquipmentInfoCallback callback) {
        Log.i(TAG, "getEquipmentInfo");
        EquipmentInfo equipmentInfo = new EquipmentInfo();
        equipmentInfo.setManufacturer("Honor");
        equipmentInfo.setModel(devModel);
        callback.onSuccess(equipmentInfo);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int connect(HealthDeviceInfo deviceInfo, ConnectCallback connectCallback) {
        if (connectCallback == null || deviceInfo == null) {
            Log.e(TAG, "connect failed: invalid param");
            return HealthDataContent.ERROR;
        }
        // nodeId 使用传入的 uniqueId
        Log.i(TAG, "connect, nodeId: " + deviceInfo.getUniqueId());
        if (this.deviceStateListener == null) {
            Log.e(TAG, "connect failed: deviceStateListener is not registered");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "start connect");
        connectCallback.onSuccess();
        // 需要将三方回调转为health的回调
        CategoryLefuScaleConnectCallback categoryLefuScaleConnectCallback = new CategoryLefuScaleConnectCallback() {
            @Override
            public void onSuccess() {
                Log.i(TAG, "connect success");
                // 连接状态通过deviceStateListener返回
                deviceStateListener.onStateChange(CallbackStatus.CONNECT_STATUS_CONNECTED, null);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                Log.i(TAG, "connect failed, errCode: " + errCode + ", errMsg: " + errMsg);
                deviceStateListener.onStateChange(CallbackStatus.CONNECT_STATUS_CONNECT_FAILED, errMsg);
            }
        };
        instance.startConnect(deviceInfo.getAddress(), devModel, categoryLefuScaleConnectCallback);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int disConnect(HealthDeviceInfo deviceInfo, ConnectCallback connectCallback) {
        if (connectCallback == null || deviceInfo == null) {
            Log.e(TAG, "disConnect failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "disConnect, nodeId: " + deviceInfo.getUniqueId());
        if (deviceStateListener == null) {
            Log.e(TAG, "disConnect failed: deviceStateListener is not registered");
            return HealthDataContent.ERROR;
        }
        connectCallback.onSuccess();
        Log.i(TAG, "start disconnect");
        // 需要将三方回调转为health的回调
        CategoryLefuScaleConnectCallback categoryLefuScaleConnectCallback = new CategoryLefuScaleConnectCallback() {
            @Override
            public void onSuccess() {
                Log.i(TAG, "disconnect success");
                deviceStateListener.onStateChange(CallbackStatus.CONNECT_STATUS_DISCONNECTED, null);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                Log.i(TAG, "disconnect failed, errCode: " + errCode + ", errMsg: " + errMsg);
                deviceStateListener.onStateChange(CallbackStatus.CONNECT_STATUS_DISCONNECT_FAILED, null);
            }
        };
        instance.disConect(deviceInfo.getAddress(), categoryLefuScaleConnectCallback);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int manageParameter(String cmd, HealthDeviceInfo healthDeviceInfo, DeviceParameter deviceParameter, InfoManageCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "manageParameter failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "manageParameter, cmd: " + cmd + ", nodeId: " + healthDeviceInfo.getUniqueId());
        // 如果不支持 manageParameter 或传入不支持的cmd，返回 CallbackStatus.METHOD_NOT_SUPPORTED
        callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.METHOD_NOT_SUPPORTED, "manageParameter is not supported");
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int manageUser(String cmd, HealthDeviceInfo healthDeviceInfo, UserInfo userInfo, InfoManageCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "manageUser failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "manageUser, cmd: " + cmd + ", nodeId: " + healthDeviceInfo.getUniqueId());

        if (HealthDataContent.CMD_SET_USERINFO.equals(cmd)) {
            Log.i(TAG, "set userInfo, birthday: " + userInfo.getBirth() + ", sex: " +
                    userInfo.isSex() + ", height: " + userInfo.getHeight());
            UserCallback userCallback = new UserCallback() {
                @Override
                public void onSuccess() {
                    Log.i(TAG, "set userInfo success");
                    callback.onUserInfoSuccess(healthDeviceInfo.getUniqueId(), null);
                }

                @Override
                public void onFailed(int errCode, String errMsg) {
                    Log.i(TAG, "set userInfo failed, errCode: " + errCode + ", errMsg: " + errMsg);
                    // 需要将三方回调转为health的回调
                    if (errCode == 1) {
                        callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.ERROR_ILLEGAL_ARGUMENT, errMsg);
                    } else if (errCode == 2) {
                        callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.INNER_ERROR, errMsg);
                    }
                }
            };
            instance.setUserInfo(healthDeviceInfo.getAddress(), userInfo, userCallback);
        } else {
            Log.i(TAG, "manageUser, " + cmd + " is not supported");
            // 如果不支持 manageUser 或传入不支持的cmd，返回 CallbackStatus.METHOD_NOT_SUPPORTED
            callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.METHOD_NOT_SUPPORTED, cmd + " is not supported");
        }
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int startMeasure(HealthDeviceInfo healthDeviceInfo, DataCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "startMeasure failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "startMeasure, nodeId: " + healthDeviceInfo.getUniqueId());
        // 需要将三方回调转为health的回调
        CategoryLefuScaleDataCallback categoryADataCallback = new CategoryLefuScaleDataCallback() {
            @Override
            public void onResult(PPBodyFatModel categoryAData) {
                Log.i(TAG, "measure result, data: " + categoryAData);
                // 将三方测量数据类转为HealthData
                HealthData healthData = DataHelper.convertHealthData(categoryAData);
                callback.onDataChanged(healthDeviceInfo.getUniqueId(), healthData);
                // 对已有测量结果类的品类，可以先转为已有的测量结果类，再在onDataChanged的入参传入toHealthData即可
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                Log.i(TAG, "measure failed, errCode: " + errCode + ", errMsg: " + errMsg);
                if (errCode == 11) {
                    callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.MEASURE_TIMEOUT, errMsg);
                } else if (errCode == 22) {
                    callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.INNER_ERROR, errMsg);
                }
            }
        };
        instance.startMeasure(healthDeviceInfo.getAddress(), categoryADataCallback);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int stopMeasure(HealthDeviceInfo healthDeviceInfo, DataCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "stopMeasure failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "stopMeasure, nodeId: " + healthDeviceInfo.getUniqueId());
        instance.stopMeasure();
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int getHistoryData(HealthDeviceInfo healthDeviceInfo, HistoryDataCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "getHistoryData failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "getHistoryData, nodeId: " + healthDeviceInfo.getUniqueId());
        HistoryCallback historyCallback = new HistoryCallback() {
            @Override
            public void onCategoryADataComing(PPBodyFatModel categoryAData) {
                Log.i(TAG, "history data: " + categoryAData);
                // 将三方测量数据类转为HealthData
                List<HealthData> list = new ArrayList<>();
                list.add(DataHelper.convertHealthData(categoryAData));
                callback.onHistoryData(healthDeviceInfo.getUniqueId(), list);
                // 对已有测量结果类的品类，可以先转为已有的测量结果类，再在onDataChanged的入参传入toHealthData即可
            }

            @Override
            public void onCategoryBDataComing(PPBodyFatModel categoryBData) {
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                Log.e(TAG, "get history data, failed: " + errCode + ", errMsg: " + errMsg);
                callback.onFailed(healthDeviceInfo.getUniqueId(), CallbackStatus.INNER_ERROR, errMsg);
            }
        };
        Log.e(TAG, "getHistoryData");
        instance.getHistoryData(healthDeviceInfo.getAddress(), historyCallback);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int clearHistoryData(HealthDeviceInfo healthDeviceInfo, ClearCallback callback) {
        if (healthDeviceInfo == null || callback == null) {
            Log.e(TAG, "clearHistoryData failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "clearHistoryData, nodeId: " + healthDeviceInfo.getUniqueId());
        // 如果不支持 clearHistoryData，返回 CallbackStatus.METHOD_NOT_SUPPORTED
        // TODO: 2022/11/9 李永平 接口参数不对应
//        callback.onFailed(CallbackStatus.METHOD_NOT_SUPPORTED, "clearHistoryData is not supported", null);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int extendCmd(String cmd, String json, ExtendCmdCallback callBack) {
        if (callBack == null) {
            Log.e(TAG, "extendCmd failed: invalid param");
            return HealthDataContent.ERROR;
        }
        Log.i(TAG, "extendCmd, cmd: " + cmd + ", json: " + json);
        // 如果不支持 extendCmd 或传入不支持的cmd，返回 CallbackStatus.METHOD_NOT_SUPPORTED
        callBack.onResponse(CallbackStatus.METHOD_NOT_SUPPORTED, "extendCmd is not supported", null);
        return HealthDataContent.SUCCESS;
    }

    @Override
    public int getDeviceCapacity(DeviceCapacityCallback callback) {
        Log.i(TAG, "getDeviceCapacity");
        DeviceCapacity deviceCapacity = new DeviceCapacity();
        deviceCapacity.setStartDiscovery(true);
        deviceCapacity.setStopDiscovery(true);
        deviceCapacity.setGetHistoryData(true);

        // 对传入cmd的方法，需要返回所有支持的cmd的List
        List<String> manageUserCmd = new ArrayList<>();
        manageUserCmd.add(HealthDataContent.CMD_SET_USERINFO);
        deviceCapacity.setManageUser(manageUserCmd);

        Log.i(TAG, "getDeviceCapacity, deviceCapacity: " + deviceCapacity);
        callback.onSuccess(deviceCapacity);
        return HealthDataContent.SUCCESS;
    }
}
