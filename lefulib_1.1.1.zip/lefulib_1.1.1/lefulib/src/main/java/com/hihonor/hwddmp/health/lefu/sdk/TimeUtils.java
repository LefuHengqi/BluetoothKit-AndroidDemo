package com.hihonor.hwddmp.health.lefu.sdk;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeUtils {


    /**
     * 计算年龄大小
     *
     * @param birthday 用例1991-02-10 -->  29
     * @return
     * @throws Exception
     */
    public static int getAgeByBirth(String birthday) {
        String strFormat1 = "yyyy-MM-dd HH:mm:ss";
        String strFormat2 = "yyyy-MM-dd";
        if (birthday.length() > strFormat2.length()) {
            String[] split = birthday.split(" ");
            birthday = split[0];
        }
        int age;
        SimpleDateFormat datesdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date birthDay = datesdf.parse(birthday);
            Calendar birh = Calendar.getInstance();
            birh.setTime(birthDay);
            Calendar cal = Calendar.getInstance();
            if (cal.before(birh)) { //出生日期晚于当前时间，无法计算
                age = -1;
                return age;
            }
            int yearNow = cal.get(Calendar.YEAR);  //当前年份
            int monthNow = cal.get(Calendar.MONTH);  //当前月份
            int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH); //当前日期
            cal.setTime(birthDay);
            int yearBirth = cal.get(Calendar.YEAR);
            int monthBirth = cal.get(Calendar.MONTH);
            int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
            age = yearNow - yearBirth;   //计算整岁数
            if (monthNow <= monthBirth) {
                if (monthNow == monthBirth) {
                    if (dayOfMonthNow < dayOfMonthBirth) age--;//当前日期在生日之前，年龄减一
                } else {
                    age--;//当前月份在生日之前，年龄减一
                }
            }
        } catch (Exception e) {
            age = -1;
        }
        return age;
    }
}
