package com.hihonor.hwddmp.health;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.hihonor.hwddmp.health.api.HealthDeviceController;
import com.hihonor.hwddmp.health.callback.InitCallback;
import com.hihonor.hwddmp.health.lefu.CategoryLefuScaleDeviceController;
import com.hihonor.hwddmp.health.lefu.sdk.InitListener;
import com.hihonor.hwddmp.health.lefu.sdk.InitStatus;
import com.hihonor.hwddmp.health.lefu.LefuScaleSDK;

// 此demo仅供接口方法实现逻辑参考，实际不能运行
// 封装包入口类，继承并实现 MeasureKit 方法
// ManufactureName 代指厂商名
public class LefuScaleMeasureKit extends MeasureKit {
    private final String TAG = "LefuScaleMeasureKit";

    private Context context;

    // 厂商鉴权所用密钥
    private final String ACCESS_KEY = "35383086-18ad-4880-8b58-3e8feeae54e1";

    // 同一厂商两种不同品类的设备，两种设备所调用的sdk接口不同
    private final String DEVICE_MODEL_A = "LFAston-B19";

    // 蓝牙名称前缀，用以区分不同设备
    private final String DEVICE_MODEL_A_PREFIX = "Honor Scale 3-";

    // 初始化SDK（初始化、鉴权）
    // 初始化结果通过回调返回
    public void init(Context context, InitCallback initCallback) {
        Log.i(TAG, "init");
        if (initCallback == null || context == null) {
            Log.e(TAG, "init failed, invalid param");
            return;
        }
        this.context = context;
        if (!isInitialized()) {
            // 调用sdk鉴权方法
            LefuScaleSDK.getInstance().init(ACCESS_KEY, this.context, new InitListener() {
                @Override
                public void onInitSuccess(InitStatus initStatus) {
                    Log.i(TAG, "init success");
                    initCallback.onSuccess();
                }

                @Override
                public void onInitFailed(String msg) {
                    Log.e(TAG, "init fail, msg: " + msg);
                    initCallback.onFailed(msg);
                }
            });
        } else {
            Log.w(TAG, "init ,LefuScaleSDK Has been initialized,  Can be used directly");
        }

    }

    // 判断MeasureKit是否初始化完成
    public boolean isInitialized() {
        return LefuScaleSDK.getInstance().isInitialized();
    }

    // 获取实际测量业务实现类，通过该类对测量生命周期进行管理。
    // 三方实现时根据设备型号等信息，返回合适的 HealthDeviceController 子类（由三方实现）
    public HealthDeviceController getHealthDeviceController(String devModel) {
        // 不同品类的设备（不能复用一套接口），返回不同的 HealthDeviceController
        if (DEVICE_MODEL_A.equals(devModel)) {
            return new CategoryLefuScaleDeviceController(context, devModel);
        }
        Log.e(TAG, "input devModel is illegal, devModel: " + devModel);
        return null;
    }

    // 根据蓝牙名称，判断设备型号并返回
    public String getDevModel(String deviceName) {
        if (TextUtils.isEmpty(deviceName)) {
            return null;
        }
        if (deviceName.startsWith(DEVICE_MODEL_A_PREFIX)) {
            return DEVICE_MODEL_A;
        }
        return null;
    }
}
