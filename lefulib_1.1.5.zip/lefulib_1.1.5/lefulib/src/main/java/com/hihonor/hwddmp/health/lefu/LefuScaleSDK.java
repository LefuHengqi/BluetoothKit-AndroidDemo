package com.hihonor.hwddmp.health.lefu;

import android.content.Context;
import android.util.Log;

import com.hihonor.hwddmp.connectkit.BuildConfig;
import com.hihonor.hwddmp.health.data.CallbackStatus;
import com.hihonor.hwddmp.health.data.UserInfo;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleConnectCallback;
import com.hihonor.hwddmp.health.lefu.sdk.CategoryLefuScaleDataCallback;
import com.hihonor.hwddmp.health.lefu.sdk.HistoryCallback;
import com.hihonor.hwddmp.health.lefu.sdk.InitListener;
import com.hihonor.hwddmp.health.lefu.sdk.InitStatus;
import com.hihonor.hwddmp.health.lefu.sdk.ScanCallBack;
import com.hihonor.hwddmp.health.lefu.sdk.TimeUtils;
import com.hihonor.hwddmp.health.lefu.sdk.UserCallback;
import com.peng.ppscale.business.ble.BleOptions;
import com.peng.ppscale.business.ble.PPScale;
import com.peng.ppscale.business.ble.listener.PPBindDeviceInterface;
import com.peng.ppscale.business.ble.listener.PPBleSendResultCallBack;
import com.peng.ppscale.business.ble.listener.PPBleStateInterface;
import com.peng.ppscale.business.ble.listener.PPDeviceInfoInterface;
import com.peng.ppscale.business.ble.listener.PPLockDataInterface;
import com.peng.ppscale.business.ble.listener.PPProcessDateInterface;
import com.peng.ppscale.business.ble.listener.ProtocalFilterImpl;
import com.peng.ppscale.business.device.PPUnitType;
import com.peng.ppscale.business.state.PPBleSwitchState;
import com.peng.ppscale.business.state.PPBleWorkState;
import com.peng.ppscale.util.Logger;
import com.peng.ppscale.util.PPUtil;
import com.peng.ppscale.vo.PPBodyBaseModel;
import com.peng.ppscale.vo.PPBodyFatModel;
import com.peng.ppscale.vo.PPDeviceModel;
import com.peng.ppscale.vo.PPScaleDefine;
import com.peng.ppscale.vo.PPScaleSendState;
import com.peng.ppscale.vo.PPUserGender;
import com.peng.ppscale.vo.PPUserModel;

public class LefuScaleSDK {
    private final String TAG = "LefuScaleSDK";

    private static volatile LefuScaleSDK instance = null;
    private boolean isInitialized;
    CategoryLefuScaleConnectCallback connectCallback;
    CategoryLefuScaleConnectCallback disConnectCallback;
    ScanCallBack scanCallBack;
    CategoryLefuScaleDataCallback dataCallback;

    private PPScale.Builder ppScaleBuilder;
    PPScale ppScale;
    private PPUserModel userModel;

    private LefuScaleSDK() {
    }

    public static LefuScaleSDK getInstance() {
        if (instance == null) {
            synchronized (LefuScaleSDK.class) {
                if (instance == null) {
                    instance = new LefuScaleSDK();
                }
            }
        }
        return instance;
    }

    public void init(String accessKey, Context context, InitListener initListener) {
        Log.i(TAG, "init, accessKey: " + accessKey);
        if (initListener != null) {
            if (accessKey == null || accessKey.isEmpty()) {
                initListener.onInitFailed("accessKey is null");
                Log.e(TAG, "init: accessKey is null ");
            } else if (context == null) {
                initListener.onInitFailed("context is null");
                Log.e(TAG, "init: context is null");
            } else {
                try {
                    PPScale.setDebug(BuildConfig.DEBUG);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "init, start init fail, debug modele open fail");
                }
                Log.i(TAG, "init, start init");
                if (ppScaleBuilder == null) {
                    ppScaleBuilder = new PPScale.Builder(context);
                } else {
                    Log.e(TAG, "init, ppScaleBuilder Has been initialized");
                }
                if (ppScale == null) {
                    ppScale = ppScaleBuilder.setProtocalFilterImpl(getProtocalFilter())
                            .setBleOptions(getBleOptions())
                            .setBleStateInterface(bleStateInterface)
                            .build();
                } else {
                    ppScaleBuilder.setProtocalFilterImpl(getProtocalFilter())
                            .setBleOptions(getBleOptions())
                            .setBleStateInterface(bleStateInterface);
                    ppScale.setBuilder(ppScaleBuilder);
                }
                Log.i(TAG, "init, init success");
                initListener.onInitSuccess(new InitStatus());
                isInitialized = true;
            }
        } else {
            Log.e(TAG, "init, initListener: initListener is null");
        }
    }

    public void scanDevice(Context context, String devModel, ScanCallBack scanCallBack) {
        Log.i(TAG, "scanDevice devModel " + devModel);
        this.scanCallBack = scanCallBack;
        ppScale.startSearchBluetoothScaleWithMacAddressList();
    }

    public void stopScan() {
        Log.i(TAG, "stopScan");
        ppScale.stopSearch();
    }

    public void startConnect(String address, String devModel, CategoryLefuScaleConnectCallback categoryAConnectCallback) {
        this.connectCallback = categoryAConnectCallback;
        Log.i(TAG, "startConnect, address: " + address + " devModel: " + devModel);

        if (userModel == null) {
            Log.e(TAG, "startConnect, Userinfo is null, Start using default user information");
            UserInfo userInfo = new UserInfo();
            userInfo.setBirth("1991-02-10");
            userInfo.setHeight(180);
            userInfo.setSex(true);
            Log.e(TAG, "startConnect, Userinfo is null, default Userinfo:" + userInfo.toString());
            setUserInfo(address, userInfo, null);
        }
        ppScale.connectAddress(address);
    }

    public void disConect(String address, CategoryLefuScaleConnectCallback categoryAConnectCallback) {
        this.disConnectCallback = categoryAConnectCallback;
        Log.i(TAG, "disConect, address: " + address);
        if (ppScale != null) {
            ppScale.disConnect();
        }
    }

    public void setUserInfo(String address, UserInfo userInfo, UserCallback userCallback) {
        Log.i(TAG, "setUserInfo, address: " + address + " userInfo: " + userInfo.toString());
        int age = TimeUtils.getAgeByBirth(userInfo.getBirth());
        if (age < 10 || age > 99) {
            Log.e(TAG, "setUserInfo, The age is error");
            if (userCallback != null) {
                userCallback.onFailed(CallbackStatus.ERROR_ILLEGAL_ARGUMENT, "The age is error");
            }
        } else if (userInfo.getHeight() < 30 || userInfo.getHeight() > 220) {
            Log.e(TAG, "setUserInfo, The height is error");
            if (userCallback != null) {
                userCallback.onFailed(CallbackStatus.ERROR_ILLEGAL_ARGUMENT, "The height is error");
            }
        } else {
            userModel = new PPUserModel.Builder().setAge(age)
                    .setHeight((int) userInfo.getHeight())
                    .setSex(userInfo.isSex() ? PPUserGender.PPUserGenderMale : PPUserGender.PPUserGenderFemale)
                    .setGroupNum(0)
                    .build();
            Log.i(TAG, "setUserInfo, userModel: " + userModel.toString());
            if (ppScaleBuilder != null) {
                ppScaleBuilder.setUserModel(userModel);
                ppScale.setBuilder(ppScaleBuilder);
                Log.i(TAG, "setUserInfo, userModel: " + userModel.toString());
                if (userCallback != null) {
                    userCallback.onSuccess();
                }
            } else {
                Log.e(TAG, "setUserInfo, The sdk is not initialized, or initialization fails");
                if (userCallback != null) {
                    userCallback.onFailed(CallbackStatus.ERROR, "The sdk is not initialized, or initialization fails");
                }
            }
        }
    }

    public void startMeasure(String address, CategoryLefuScaleDataCallback categoryDataCallback) {
        this.dataCallback = categoryDataCallback;
        if (categoryDataCallback == null) {
            Log.e(TAG, "startMeasure, categoryDataCallback is null, address = " + address);
        } else {
            Log.i(TAG, "startMeasure");
        }
    }

    public void stopMeasure() {
        this.dataCallback = null;
        Log.i(TAG, "stopMeasure");
    }

    public void getHistoryData(String address, HistoryCallback historyCallback) {
        Log.i(TAG, "getHistoryData, address: " + address);
    }

    public boolean isInitialized() {
        Log.i(TAG, "isInitialized, isInitialized: " + isInitialized);
        return isInitialized;
    }

    /**
     * Connection configuration
     *
     * @return
     */
    private BleOptions getBleOptions() {
        return new BleOptions.Builder()
                .setSearchTag(BleOptions.SEARCH_TAG_NORMAL)
                .build();
    }

    /**
     * 解析数据回调
     * <p>
     * bodyFatModel 身体数据
     * deviceModel 设备信息
     */
    private ProtocalFilterImpl getProtocalFilter() {
        final ProtocalFilterImpl protocalFilter = new ProtocalFilterImpl();
        protocalFilter.setBindDeviceInterface(new PPBindDeviceInterface() {

            @Override
            public void onBindDevice(PPDeviceModel deviceModel) {
                if (scanCallBack != null) {
                    scanCallBack.getScanResult(deviceModel);
                }
            }
        });

        protocalFilter.setPPProcessDateInterface(new PPProcessDateInterface() {

            // 过程数据
            @Override
            public void monitorProcessData(PPBodyBaseModel bodyBaseModel, PPDeviceModel deviceModel) {
                if (dataCallback != null) {
                    if (bodyBaseModel.getPpWeightKg() >= 300) {
                        Log.e(TAG, "monitorProcessData, weight is overweight ");
                        dataCallback.onFailed(CallbackStatus.MEASURE_FAILED, "overweight");
                    } else if (userModel == null) {
                        Log.e(TAG, "monitorProcessData, userinfo is null ");
                        dataCallback.onFailed(CallbackStatus.ERROR_ILLEGAL_ARGUMENT, "userinfo is null");
                    } else {
                        PPBodyFatModel ppBodyFatModel = new PPBodyFatModel(bodyBaseModel.getPpWeightKg(), userModel, deviceModel, PPUnitType.Unit_KG);
                        ppBodyFatModel.setPpWeightKg(bodyBaseModel.getPpWeightKg());
                        ppBodyFatModel.setDeviceModel(deviceModel);
                        Log.i(TAG, "monitorProcessData, weight: " + bodyBaseModel.getPpWeightKg());
                        dataCallback.onResult(ppBodyFatModel, false);
                    }
                }
            }
        });
        protocalFilter.setPPLockDataInterface(new PPLockDataInterface() {

            //锁定数据
            @Override
            public void monitorLockData(PPBodyFatModel bodyFatModel, PPDeviceModel deviceModel) {
                onDataLock(bodyFatModel, deviceModel);
            }

            @Override
            public void monitorOverWeight() {
                Logger.e("over weight ");
                dataCallback.onFailed(CallbackStatus.MEASURE_FAILED, "overweight");
            }
        });

        protocalFilter.setDeviceInfoInterface(new PPDeviceInfoInterface() {

            @Override
            public void serialNumber(PPDeviceModel deviceModel) {
                Logger.d("getSerialNumber  " + deviceModel.getSerialNumber());
            }

            @Override
            public void onIlluminationChange(int illumination) {

            }

            @Override
            public void readDeviceInfoComplete(PPDeviceModel deviceModel) {
                //如果需要modelNumber 设备型号信息，则要主动发起连接并且见监听readDeviceInfoComplete时回调
                Logger.d("DeviceInfo :  " + deviceModel.getModelNumber());
//                if (deviceModel.deviceConnectType != PPScaleDefine.PPDeviceConnectType.PPDeviceConnectTypeDirect) {
//                        }
                Logger.d("DeviceInfo :  " + deviceModel.toString());
            }
        });
        return protocalFilter;
    }

    private void onDataLock(PPBodyFatModel bodyFatModel, PPDeviceModel deviceModel) {
        if (bodyFatModel != null) {
            if (bodyFatModel.isHeartRateEnd()) {
                Log.i(TAG, "onDataLock, 测量结束");
                Logger.d("monitorLockData  bodyFatModel weightKg = " + bodyFatModel.toString());
                Log.i(TAG, "monitorLockData, weight: " + bodyFatModel.getPpWeightKg());
                if (deviceModel.deviceType == PPScaleDefine.PPDeviceType.PPDeviceTypeCC) {
                    //Bluetooth WiFi scale
                    Log.i(TAG, "onDataLock, WiFi scale");
                } else {
                    //Ordinary bluetooth scale
                    Log.i(TAG, "onDataLock, bluetooth scale");
                }
                if (dataCallback != null) {
                    dataCallback.onResult(bodyFatModel, true);
                }
            } else {
                Log.i(TAG, "onDataLock, 正在测量心率");
            }
        }
    }

    PPBleStateInterface bleStateInterface = new PPBleStateInterface() {
        @Override
        public void monitorBluetoothWorkState(PPBleWorkState ppBleWorkState, PPDeviceModel deviceModel) {
            Log.i(TAG, "monitorBluetoothWorkState, ppBleWorkState: " + ppBleWorkState);
            if (ppBleWorkState == PPBleWorkState.PPBleWorkStateConnected) {
                if (connectCallback != null) {
                    connectCallback.onSuccess();
                }
            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkStateConnecting) {

            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkStateDisconnected) {
                if (disConnectCallback != null) {
                    disConnectCallback.onSuccess();
                }
            } else if (ppBleWorkState == PPBleWorkState.PPBleStateSearchCanceled) {
            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkSearchTimeOut) {

            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkStateSearching) {

            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkStateWritable) {
                //可写状态，可以发送指令，例如切换单位，获取历史数据等
//                sendUnitDataScale(deviceModel);
            } else if (ppBleWorkState == PPBleWorkState.PPBleWorkStateConnectable) {

            } else {
            }
        }

        @Override
        public void monitorBluetoothSwitchState(PPBleSwitchState ppBleSwitchState) {
            if (ppBleSwitchState == PPBleSwitchState.PPBleSwitchStateOff) {
            } else if (ppBleSwitchState == PPBleSwitchState.PPBleSwitchStateOn) {
            } else {
            }
        }
    };

    /**
     * 切换单位指令
     */
    private void sendUnitDataScale(final PPDeviceModel deviceModel) {
        if (ppScale != null) {
            if (deviceModel.getDeviceCalcuteType() == PPScaleDefine.PPDeviceCalcuteType.PPDeviceCalcuteTypeInScale) {
                //秤端计算，需要发送身体详情数据给秤，发送完成后不断开（切换单位）
                ppScale.sendData2ElectronicScale(PPUnitType.Unit_KG);
            } else {
                //切换单位
                ppScale.sendUnitDataScale(PPUnitType.Unit_KG);
                ppScale.setSendResultCallBack(new PPBleSendResultCallBack() {
                    @Override
                    public void onResult(PPScaleSendState sendState) {
                        if (sendState == PPScaleSendState.PP_SEND_FAIL) {
                            //Failed to send
                        } else if (sendState == PPScaleSendState.PP_SEND_SUCCESS) {
                            //sentSuccessfully
                        } else if (sendState == PPScaleSendState.PP_DEVICE_ERROR) {
                            //Device error, indicating that the command is not supported
                        } else if (sendState == PPScaleSendState.PP_DEVICE_NO_CONNECT) {
                            //deviceNotConnected
                        }
//                        if (deviceModel != null && deviceModel.deviceConnectType != PPScaleDefine.PPDeviceConnectType.PPDeviceConnectTypeDirect) {
//                            disConnect();
//                        }
                    }
                });
            }
        }
    }
}
